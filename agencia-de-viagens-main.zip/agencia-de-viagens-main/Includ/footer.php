<link rel="stylesheet" href="style.css">
<footer id="contato">
    <div class="rodape limitar-secao">
    <div class="conteudo-rodape">
      <h3>Contato</h3>
      <p class="contato-cidade">Rio de janeiro, RJ</p>
      <p class="contato-telefone">Telefone: (21) 9999-9999</p>
      <p class="contato-email">Email: contato@agencia.com.br</p>
    </div>
    <div class="conteudo-rodape">
      <h3>Nossas redes sociais</h3>
      <p class="face">/AgenciaDeViagem</p>
      <p class="insta">@AgenciaDeViagem</p>
      <p class="twt">@AgenciaDeViagem</p>
    </div>
  </div>
    <p class="des">&copy;Desenvolvido por Gabriel Lessa</p>
  </footer>
  </body>
</html>

<!-- funcionando -->